/* Andi Djurdjevic
 * CS-320 Software Test, Automation
 * Dec 7, 2025
 * */

package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date future = new Date(System.currentTimeMillis() + 1000);
        Appointment appointment = new Appointment("ABC123", future, "Dentist Visit");

        assertEquals("ABC123", appointment.getAppointmentId());
        assertEquals(future, appointment.getAppointmentDate());
        assertEquals("Dentist Visit", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdTooLong() {
        Date future = new Date(System.currentTimeMillis() + 1000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", future, "Valid");
        });
    }

    @Test
    public void testAppointmentIdNull() {
        Date future = new Date(System.currentTimeMillis() + 1000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, future, "Valid");
        });
    }

    @Test
    public void testDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("ID", null, "Valid");
        });
    }

    @Test
    public void testDateCannotBePast() {
        Date past = new Date(System.currentTimeMillis() - 1000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("ID", past, "Valid");
        });
    }

    @Test
    public void testDescriptionNull() {
        Date future = new Date(System.currentTimeMillis() + 1000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("ID", future, null);
        });
    }

    @Test
    public void testDescriptionTooLong() {
        Date future = new Date(System.currentTimeMillis() + 1000);
        String longDesc = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("ID", future, longDesc);
        });
    }
    @Test
    public void testSetAppointmentDateValid() {
        Date future = new Date(System.currentTimeMillis() + 5000);
        Appointment a = new Appointment("ID", future, "Initial");

        Date laterFuture = new Date(System.currentTimeMillis() + 10000);
        a.setAppointmentDate(laterFuture);

        assertEquals(laterFuture, a.getAppointmentDate());
    }

    @Test
    public void testSetAppointmentDatePast_throws() {
        Date future = new Date(System.currentTimeMillis() + 5000);
        Appointment a = new Appointment("ID", future, "Initial");

        Date past = new Date(System.currentTimeMillis() - 1000);
        assertThrows(IllegalArgumentException.class, () ->
            a.setAppointmentDate(past)
        );
    }

    @Test
    public void testSetDescriptionValid() {
        Date future = new Date(System.currentTimeMillis() + 5000);
        Appointment a = new Appointment("ID", future, "Initial");

        a.setDescription("Updated description");
        assertEquals("Updated description", a.getDescription());
    }

    @Test
    public void testSetDescriptionInvalid() {
        Date future = new Date(System.currentTimeMillis() + 5000);
        Appointment a = new Appointment("ID", future, "Initial");

        assertThrows(IllegalArgumentException.class, () -> a.setDescription(null));

        String longDesc = "a".repeat(51); // 51 chars
        assertThrows(IllegalArgumentException.class, () -> a.setDescription(longDesc));
    }
}
