/* Andi Djurdjevic
 * CS-320 Software Test, Automation
 * Dec 7, 2025
 * */

package appointmentservice;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    private Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(String appointmentId, Date appointmentDate, String description) {
        if (appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment already exists");
        }
        Appointment newAppointment = new Appointment(appointmentId, appointmentDate, description);
        appointments.put(appointmentId, newAppointment);
    }

    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment does not exist");
        }
        appointments.remove(appointmentId);
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
