/* Andi Djurdjevic
 * CS-320 Software Test, Automation
 * Dec 7, 2025
 * */

package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 1000);

        service.addAppointment("A1", future, "Visit");

        assertNotNull(service.getAppointment("A1"));
    }

    @Test
    public void testAddDuplicateIDThrowsException() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 1000);

        service.addAppointment("A1", future, "First");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("A1", future, "Second");
        });
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 1000);

        service.addAppointment("A2", future, "Visit");
        service.deleteAppointment("A2");

        assertNull(service.getAppointment("A2"));
    }

    @Test
    public void testDeleteInvalidIDThrowsException() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("BAD");
        });
    }
};
