/* Andi Djurdjevic
 * CS-320 Software Test, Automation
 * Dec 7, 2025
 * */

package taskservice;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    private Map<String, Task> tasks = new HashMap<>();

    public void addTask(String taskId, String name, String description) {

        if (tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID already exists");
        }

        Task newTask = new Task(taskId, name, description);

        tasks.put(taskId, newTask);
    }

    public void deleteTask(String taskId) {

        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }

        tasks.remove(taskId);
    }

    public void updateTaskName(String taskId, String newName) {

        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }

        task.setName(newName);
    }

    public void updateTaskDescription(String taskId, String newDescription) {

        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }

        task.setDescription(newDescription);
    }
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}