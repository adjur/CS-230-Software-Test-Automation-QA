/* Andi Djurdjevic
 * CS-320 Software Test, Automation
 * Dec 7, 2025
 * */

package taskservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void testAddTaskSuccessfully() {
        TaskService service = new TaskService();

        service.addTask("1", "Task One", "First task description");

        Task task = service.getTask("1");

        assertNotNull(task);
        assertEquals("Task One", task.getName());
        assertEquals("First task description", task.getDescription());
    }

    @Test
    void testAddTaskWithDuplicateIdThrowsException() {
        TaskService service = new TaskService();

        service.addTask("1", "Task One", "First task description");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask("1", "Task Two", "Second task description");
        });
    }

    @Test
    void testDeleteTaskSuccessfully() {
        TaskService service = new TaskService();

        service.addTask("1", "Task One", "First task description");
        service.deleteTask("1");

        assertNull(service.getTask("1"));
    }

    @Test
    void testDeleteNonexistentTaskThrowsException() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("999");
        });
    }

    @Test
    void testUpdateTaskNameSuccessfully() {
        TaskService service = new TaskService();

        service.addTask("1", "Old Name", "Description");
        service.updateTaskName("1", "New Name");

        Task task = service.getTask("1");
        assertEquals("New Name", task.getName());
    }

    @Test
    void testUpdateTaskDescriptionSuccessfully() {
        TaskService service = new TaskService();

        service.addTask("1", "Name", "Old description");
        service.updateTaskDescription("1", "New description");

        Task task = service.getTask("1");
        assertEquals("New description", task.getDescription());
    }

    @Test
    void testUpdateNameForNonexistentTaskThrowsException() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("999", "New Name");
        });
    }

    @Test
    void testUpdateDescriptionForNonexistentTaskThrowsException() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("999", "New description");
        });
    }
}

