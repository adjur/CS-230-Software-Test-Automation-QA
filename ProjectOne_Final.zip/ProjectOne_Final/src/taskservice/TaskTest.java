/* Andi Djurdjevic
 * CS-320 Software Test, Automation
 * Dec 7, 2025
 * */

package taskservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("12345", "Test Name", "Test description here");

        assertEquals("12345", task.getTaskId());
        assertEquals("Test Name", task.getName());
        assertEquals("Test description here", task.getDescription());
    }

    @Test
    void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Description");
        });
    }

    @Test
    void testTaskIdCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description");
        });
    }

    @Test
    void testNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Description");
        });
    }

    @Test
    void testNameCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "This name is too long", "Description");
        });
    }

    @Test
    void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Name", null);
        });
    }

    @Test
    void testDescriptionCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Name",
                    "This description is more than fifty characters long.");
        });
    }

    @Test
    void testSetNameUpdatesValue() {
        Task task = new Task("12345", "Old Name", "Description");
        task.setName("New Name");

        assertEquals("New Name", task.getName());
    }

    @Test
    void testSetNameRejectsInvalidValue() {
        Task task = new Task("12345", "Old Name", "Description");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("This name is too long");
        });
    }

    @Test
    void testSetDescriptionUpdatesValue() {
        Task task = new Task("12345", "Name", "Old description");
        task.setDescription("New description");

        assertEquals("New description", task.getDescription());
    }

    @Test
    void testSetDescriptionRejectsInvalidValue() {
        Task task = new Task("12345", "Name", "Old description");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(
                "This description is more than fifty characters long.");
        });
    }
}
