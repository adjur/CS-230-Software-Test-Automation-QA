/* Andi Djurdjevic
 * CS-320 Software Test, Automation
 * Dec 7, 2025
 * */

package contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }

        String id = contact.getContactID();

        // makes sure no two contacts have the same ID
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("A contact with this ID already exists");
        }

        // stores the contact using its ID as the label
        contacts.put(id, contact);
    }

    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }

    public boolean deleteContact(String contactID) {
        if (contacts.containsKey(contactID)) {
            contacts.remove(contactID);
            return true;
        }
        return false;
    }

    public boolean updateContact(String contactID, 
                                 String firstName, 
                                 String lastName, 
                                 String phoneNumber, 
                                 String address) {

        Contact contact = contacts.get(contactID);

        if (contact == null) {
            return false; // no contact found
        }

        if (firstName != null) {
            contact.setFirstName(firstName);
        }

        if (lastName != null) {
            contact.setLastName(lastName);
        }

        if (phoneNumber != null) {
            contact.setPhoneNumber(phoneNumber);
        }

        if (address != null) {
            contact.setAddress(address);
        }

        return true;
    }
}
