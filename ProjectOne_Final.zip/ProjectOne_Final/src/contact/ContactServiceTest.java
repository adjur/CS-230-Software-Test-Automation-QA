/* Andi Djurdjevic
 * CS-320 Software Test, Automation
 * Dec 7, 2025
 * */

package contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    void addContact_storesAndRetrieves() {
        ContactService service = new ContactService();
        Contact c = new Contact("001", "John", "Doe", "1234567890", "123 Elm St");

        service.addContact(c);

        Contact fetched = service.getContact("001");
        assertNotNull(fetched, "Contact should be stored and retrievable");
        assertEquals("John", fetched.getFirstName());
        assertEquals("Doe", fetched.getLastName());
        assertEquals("1234567890", fetched.getPhoneNumber());
        assertEquals("123 Elm St", fetched.getAddress());
    }

    @Test
    void addContact_duplicateId_throws() {
        ContactService service = new ContactService();
        Contact c1 = new Contact("001", "John", "Doe", "1234567890", "123 Elm St");
        Contact c2 = new Contact("001", "Jane", "Smith", "0987654321", "456 Oak St");

        service.addContact(c1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(c2),
                "Adding a duplicate ID should throw");
    }

    @Test
    void deleteContact_removesById_andReturnsStatus() {
        ContactService service = new ContactService();
        Contact c = new Contact("002", "Ava", "Lee", "1112223333", "789 Pine Ave");

        service.addContact(c);

        assertTrue(service.deleteContact("002"), "Existing contact should delete and return true");
        assertNull(service.getContact("002"), "Deleted contact should no longer be retrievable");

        // Deleting again should return false (nothing to delete)
        assertFalse(service.deleteContact("002"));
    }

    @Test
    void updateContact_updatesOnlyProvidedFields() {
        ContactService service = new ContactService();
        Contact c = new Contact("003", "Max", "Kim", "2223334444", "10 Oak Rd");
        service.addContact(c);

        boolean updated = service.updateContact("003",
                "Mia",
                null,
                "5556667777",
                null);

        assertTrue(updated, "Update should return true for existing contact");

        Contact fetched = service.getContact("003");
        assertEquals("Mia", fetched.getFirstName());
        assertEquals("Kim", fetched.getLastName(), "Last name should remain unchanged");
        assertEquals("5556667777", fetched.getPhoneNumber());
        assertEquals("10 Oak Rd", fetched.getAddress(), "Address should remain unchanged");
    }

    @Test
    void updateContact_missingId_returnsFalse() {
        ContactService service = new ContactService();

        boolean result = service.updateContact("no-such-id", "A", "B", "1234567890", "X");
        assertFalse(result, "Updating a non-existent contact should return false");
    }

    @Test
    void updateContact_invalidField_throwsFromContactValidation() {
        ContactService service = new ContactService();
        Contact c = new Contact("004", "Ana", "Yu", "3334445555", "9 Birch St");
        service.addContact(c);

        assertThrows(IllegalArgumentException.class, () ->
                service.updateContact("004", null, null, "12345", null));
    }
}
