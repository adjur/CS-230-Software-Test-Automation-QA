/* Andi Djurdjevic
 * CS-320 Software Test, Automation
 * Dec 7, 2025
 * */

package contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    void createsValidContact() {
        Contact c = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        assertEquals("12345", c.getContactID());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhoneNumber());
        assertEquals("123 Elm Street", c.getAddress());
    }

    @Test
    void contactId_null_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(null, "John", "Doe", "1234567890", "Addr")
        );
    }

    @Test
    void contactId_tooLong_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345678901", "John", "Doe", "1234567890", "Addr") // 11 chars
        );
    }

    @Test
    void firstName_null_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1", null, "Doe", "1234567890", "Addr")
        );
    }

    @Test
    void firstName_tooLong_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1", "ABCDEFGHIJK", "Doe", "1234567890", "Addr") // 11
        );
    }

    @Test
    void lastName_null_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1", "John", null, "1234567890", "Addr")
        );
    }

    @Test
    void lastName_tooLong_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1", "John", "ABCDEFGHIJK", "1234567890", "Addr") // 11
        );
    }

    @Test
    void phone_null_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1", "John", "Doe", null, "Addr")
        );
    }

    @Test
    void phone_notTenDigits_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1", "John", "Doe", "12345", "Addr")
        );
    }

    @Test
    void phone_hasNonDigits_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1", "John", "Doe", "12345abcde", "Addr")
        );
    }

    @Test
    void address_null_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1", "John", "Doe", "1234567890", null)
        );
    }

    @Test
    void address_tooLong_throws() {
        String longAddress = "1234567890123456789012345678901"; // 31 chars
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1", "John", "Doe", "1234567890", longAddress)
        );
    }

    @Test
    void setters_updateFields_whenValid() {
        Contact c = new Contact("9", "John", "Doe", "1234567890", "123 Elm");
        c.setFirstName("Jane");
        c.setLastName("Roe");
        c.setPhoneNumber("0987654321");
        c.setAddress("456 Oak Ave");
        assertAll(
            () -> assertEquals("Jane", c.getFirstName()),
            () -> assertEquals("Roe", c.getLastName()),
            () -> assertEquals("0987654321", c.getPhoneNumber()),
            () -> assertEquals("456 Oak Ave", c.getAddress())
        );
    }

    @Test
    void setters_rejectInvalidValues() {
        Contact c = new Contact("9", "John", "Doe", "1234567890", "123 Elm");

        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName("ABCDEFGHIJK")); // 11

        assertThrows(IllegalArgumentException.class, () -> c.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("ABCDEFGHIJK")); // 11

        assertThrows(IllegalArgumentException.class, () -> c.setPhoneNumber(null));
        assertThrows(IllegalArgumentException.class, () -> c.setPhoneNumber("12345"));
        assertThrows(IllegalArgumentException.class, () -> c.setPhoneNumber("123456789a"));

        assertThrows(IllegalArgumentException.class, () -> c.setAddress(null));
        assertThrows(IllegalArgumentException.class, () -> c.setAddress(
            "1234567890123456789012345678901" // 31
        ));
    }

    @Test
    void contactId_isNotUpdatable() {
        Contact c = new Contact("123", "A", "B", "1234567890", "Addr");
        assertEquals("123", c.getContactID());
    }
}